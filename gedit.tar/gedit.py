#!/usr/bin/env python

import commands

commands.getoutput("ssh -X 127.0.0.1 gedit")
